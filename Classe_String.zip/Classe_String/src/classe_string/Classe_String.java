/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package classe_string;

/**
 *
 * @author Bia&Bina
 */
public class Classe_String {

    public static void main(String[] args) {

        // 1️⃣ Instanciar um objeto String com o seu nome
        String nome = " Beatriz da Silva Machado ";

        // Exibir o nome original
        System.out.println("Nome original: " + nome + "");

        // Contar a quantidade de caracteres (inclui espaços)
        int qtdCaracteres = nome.length();
        System.out.println("Quantidade de caracteres (com espacos): " + qtdCaracteres);

        // 2️⃣ Remover espaços em branco do início e do fim
        String nomeSemEspacos = nome.trim();
        System.out.println("Nome sem espacos extras: " + nomeSemEspacos + "");

        // 3️⃣ Passar todos os caracteres para maiúsculo
        String nomeMaiusculo = nomeSemEspacos.toUpperCase();
        System.out.println("Nome em maiusculo: " + nomeMaiusculo);

        // 4️⃣ Separar nome e sobrenome
        String[] partes = nomeSemEspacos.split(" ");
        String primeiroNome = partes[0];
        String ultimoSobrenome = partes[partes.length - 1];

        System.out.println("Primeiro nome: " + primeiroNome);
        System.out.println("Ultimo sobrenome: " + ultimoSobrenome);
    }

}

